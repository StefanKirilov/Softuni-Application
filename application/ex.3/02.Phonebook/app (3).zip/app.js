let url = `http://localhost:3030/jsonstore/phonebook`;
let btnLoad = document.getElementById('btnLoad');
let btnCreate = document.getElementById('btnCreate');
let ul = document.getElementById('phonebook');
let personInput = document.getElementById('person');
let phoneInput = document.getElementById('phone');

function attachEvents() {
    btnLoad.addEventListener('click', loadInfo);
    btnCreate.addEventListener('click', createInfo);
}

async function loadInfo(e){

    ul.replaceChildren();

    let response = await fetch(url);
    if(!response.ok){
        throw new Error('Error');
    }
    let data = await response.json();
    let arr = Object.values(data);

    for (const x of arr) {
       let li = document.createElement('li');
       li.textContent = `${x.person}:${x.phone}`;
       li.style.display = 'inline';
       let btnDelete = document.createElement('button');
       btnDelete.textContent = 'Delete';
       btnDelete.setAttribute('id', x._id);
       btnDelete.addEventListener('click', deleteInfo)
       let br = document.createElement('br');
       ul.appendChild(li);
       li.appendChild(btnDelete);
       ul.appendChild(br);
       
    }
}

async function deleteInfo(e){

    let option = {
        method: 'DELETE',
    }

    let id = e.target.getAttribute('id');
    e.target.parentNode.remove();

    let response = await fetch(`${url}/${id}`, option);

    loadInfo()
}

async function createInfo(e){

    if (!personInput.value && !phoneInput.value) {
        alert('All fields are required');
        }


    let body = {
        "person": `${personInput.value}`,
         "phone": `${phoneInput.value}`
    }

    let option = {
        method: 'POST',
        headers: {
            'content-type': 'application/json',
        },
        body: JSON.stringify(body)
    }

    let response = await fetch(url, option);
    let data = response.json();
    console.log(data);

    personInput.value = '';
    phoneInput.value = '';

 
}

attachEvents();