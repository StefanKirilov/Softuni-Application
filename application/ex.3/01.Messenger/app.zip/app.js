let url = `http://localhost:3030/jsonstore/messenger`;
let btnSend = document.getElementById('submit');
let btnRefresh = document.getElementById('refresh');
let messages = document.querySelector('#messages');
let author = document.querySelector('input[name=author]');
let content = document.querySelector('input[name=content]');

function attachEvents() {
    btnRefresh.addEventListener('click', showMessages);
    btnSend.addEventListener('click', sendMessage);
}

async function showMessages(){

    let response = await fetch(url);
    if(!response.ok){
        throw new Error('Error');
    }
    let data = await response.json();
    let result = '';
    let arr = Object.values(data);
    for (const x of arr) {
        result += `${x.author}: ${x.content}`
        result += '\n'
    }
    messages.value = result;
}

async function sendMessage(){

    if (!author.value && !content.value) {
        alert('All fields are required');
    }
    let body = {
        author: author.value,
        content: content.value, 
    }

    let option = {
            method: 'POST',
            headers: {
                'content-type': 'application/json',
            },
            body: JSON.stringify(body)
        }

        let response = await fetch(url,option);
        if(!response.ok){
            throw new Error('Error');
        }
        let data = await response.json();
        
        author.value = '';
        content.value = '';

}

attachEvents();